"""Interactive terminal menu for the maze."""
import random
from typing import Any, Dict, Optional

from .board import Grid, Point
from .display import WALL_COLORS, render
from .generator import MazeGenerator
from .imperfect import remove_dead_ends
from .pattern import pattern_42
from .solver import place_endpoints, solve
from .writer import build_output, write_output


class Menu:
    """Show the maze and let the user change how it is displayed."""
    def __init__(self, config: Dict[str, Any]) -> None:
        """Generate the first maze from the config.

        Args:
            config: The validated configuration dictionary.
        """
        seed: Optional[int] = config.get("seed")
        if seed is None:
            seed = random.randrange(2**32)
        self.seed: int = seed
        self.config = config
        self.show_path = False
        self.color_index = 0
        self.grid = Grid(config["width"], config["height"])
        self.entry = Point(0, 0)
        self.exit_ = Point(0, 0)
        self.letters = ""
        self.notice = ""
        self.regenerate()

    def regenerate(self) -> None:
        """Build a new maze from the config, solve it and save it."""
        width = self.config["width"]
        height = self.config["height"]
        self.grid = Grid(width, height)
        blocked = pattern_42(width, height)
        self.notice = ""
        if not blocked:
            self.notice = "Error: maze too small to draw the '42' pattern."

        entry = Point(*self.config["entry"])
        exit_ = Point(*self.config["exit"])
        self.entry, self.exit_ = place_endpoints(
            self.grid, entry, exit_, blocked
        )

        generator = MazeGenerator(self.grid, self.seed, blocked)
        generator.generate()
        if not self.config["perfect"]:
            remove_dead_ends(self.grid, blocked, generator.rng)
        self.letters = solve(self.grid, self.entry, self.exit_)

        text = build_output(self.grid, self.entry, self.exit_, self.letters)
        write_output(text, self.config["output_file"])

    def regenerate_new_seed(self) -> None:
        """Pick a new random seed and build a new maze with it."""
        self.seed = random.randrange(2**32)
        self.regenerate()

    def draw(self) -> None:
        """Clear the screen and draw the maze."""
        letters = self.letters if self.show_path else ""
        color = WALL_COLORS[self.color_index]
        print("\033[H\033[J", end="")
        print(render(self.grid, self.entry, self.exit_, letters, color))
        print(f"Seed: {self.seed}")
        if self.notice:
            print(self.notice)

    def toggle_path(self) -> None:
        """Show the path if hidden, hide it if shown."""
        self.show_path = not self.show_path

    def next_color(self) -> None:
        """Move to the next wall colour."""
        self.color_index = (self.color_index + 1) % len(WALL_COLORS)

    def run(self) -> None:
        """Show the menu until the user quits."""
        while True:
            self.draw()
            print("=== A-Maze-ing ===")
            print("1. Re-generate a new maze (new seed)")
            print("2. Re-generate the same maze (same seed)")
            print("3. Show / Hide the shortest path")
            print("4. Rotate the wall colours")
            print("5. Quit")
            try:
                choice = input("Choice? (1-5): ").strip()
            except (EOFError, KeyboardInterrupt):
                return
            if choice == "1":
                self.regenerate_new_seed()
            elif choice == "2":
                self.regenerate()
            elif choice == "3":
                self.toggle_path()
            elif choice == "4":
                self.next_color()
            elif choice == "5":
                return
